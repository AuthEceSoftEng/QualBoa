public class ComplexNumber {
    public ComplexNumber(double i, double j);
    public double getRealPart();
    public double getImaginaryPart();
    public ComplexNumber add(ComplexNumber i);
}
